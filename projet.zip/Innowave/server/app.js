const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const axios = require('axios')

mongoose.connect('mongodb://localhost:27017/innowave', {useNewUrlParser:true,useUnifiedTopology: true}).catch(error => console.log(error));


const spotlist = require('../models/spotlist')
const weather = require('../models/weather')
const utils = require('../utils/fonction');
const { json } = require('body-parser');


const router = express()
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
router.use(bodyParser.raw());

const port = 8888
const API_KEY_GOOGLE = 'AIzaSyAZesRj8lR2CzCTxIuoyIU9JwnBzpNZ9aE'
const API_STORMGLASS_PREMIUM = '9ee7f2e8-29dc-11eb-a5a9-0242ac130002-9ee7f360-29dc-11eb-a5a9-0242ac130002'

router.post('/spots', function(req,res){

  //get the information from post method 
    console.log('Got a new message',req.body);

    var rayon = req.body.Rayon
    var latitude = req.body.Latitude
    var longitude = req.body.Longitude

  //initialise json file
    obj = [];
    info_spot = ""

  // data in database - We would like to find which spot in nearest from position 
    spotlist.find({},function(err,data){
  
      //get all distance - bird flight distance 
      for(i=0;i<data.length-1;i++){
        distance = utils.get_distance(latitude,longitude,data[i].Latitude,data[i].Longitude)
        if(rayon >= distance){
          info_spot += data[i].Latitude.toString() +"," + data[i].Longitude.toString() + "|"
          var info = {
                      "spotId" : data[i].id,
                      "spotName" : data[i].Spotname,
                      "city" : data[i].City
                    }
          obj.push(info)
        }
      }
    }).then((data)=> {

      // get the answer by google 
      axios.get(
        'https://maps.googleapis.com/maps/api/distancematrix/json',{
        
          params: {
            'origins': latitude.toString()+','+longitude.toString(),
            'destinations': info_spot,
            'units' : 'metrics',
            'key' : API_KEY_GOOGLE
          }
        }).then((reponse) => {
          
          try {
            for (i=0; i<reponse.data.rows[0].elements.length;i++){
              obj[i]['adresse'] = reponse.data.destination_addresses[i]
              obj[i]['distance'] = reponse.data.rows[0].elements[i].distance.text
              obj[i]['distance_int'] = reponse.data.rows[0].elements[i].distance.value
              obj[i]['duration'] = reponse.data.rows[0].elements[i].duration.text
              obj[i]['duration_int'] = reponse.data.rows[0].elements[i].duration.value
            }
          }catch(error){
              console.log(error)
              obj = []
          }
        },(error) => {
          obj = []
          console.log(error);
        }
      ).then(() =>{
        obj.sort(utils.sort_distance_array("distance_int"));
        for (i=0;i<obj.length;i++){
          if (obj[i].distance_int > rayon*1000){
            obj.splice(i,1)
            i=i-1
          }
        }
        console.log('Proximity spots message send')
        res.json(obj)
      });
    })
});


router.get("/spots/:id_spot", function(req,res){
    console.log('New Request for spot :', req.params.id_spot)
    console.log(req.params.id_spot)
    weather.find({"spot_id":req.params.id_spot}, function(err,data){
      if(err){
        console.log('Spot ID not available in the database')
        console.log('Msg Sent : \n []')
        res.json("[]")
      }else{
        console.log('Msg Sent for spot : ', data)
        res.json(data)
      }
    }) 
});

router.listen(port, () => {
    console.log(`Listening ${port}`)
})

