function get_distance(latA,longA,latB,longB){
    
    const r = 6378.137
    dLon = toRad(longB-longA)
    
    latA = toRad(latA)
    latB = toRad(latB)
    longA = toRad(longA)
    longB = toRad(longB)
    
    coslat = Math.cos(latA)*Math.cos(latB)*Math.cos(dLon)
    sinlat = Math.sin(latA)*Math.sin(latB)

    distance = r * Math.acos(sinlat+coslat)
    distance = Math.round(distance*10)/10
    
    return distance;
    
}

function toRad(Value){
    return Value * Math.PI / 180
}

function sort_distance_array(property){
    return function(a,b){
        if(a[property] > b[property])  
         return 1;  
        else if(a[property] < b[property])  
         return -1;  
    return 0;
    }
}


exports.get_distance = get_distance;
exports.sort_distance_array = sort_distance_array;
